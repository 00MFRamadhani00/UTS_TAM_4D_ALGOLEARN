package com.fadhilah.algolearn;

public class ItemSub {
    private String title;

    private int index;

    public String getTitle() {
        return title;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
