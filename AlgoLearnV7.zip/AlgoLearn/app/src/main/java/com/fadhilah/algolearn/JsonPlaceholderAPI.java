package com.fadhilah.algolearn;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface JsonPlaceholderAPI {
    @GET("comments")
    Call<List<Comment>> getComments();
}

