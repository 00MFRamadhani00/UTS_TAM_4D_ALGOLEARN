package com.fadhilah.algolearn;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SortBubbleSortPause extends AppCompatActivity implements View.OnClickListener {
    private ImageView imageView;
    private TextView deskripsi;
    private Context context;
    Handler handler;
    Button btnPauseDanPlay, btnBackToSubMenu;
    DatabaseReference database = FirebaseDatabase.getInstance().getReference().child("Link");

    private Retrofit retrofit;
    private JsonPlaceholderAPI jsonPlaceholderAPI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sort_bubble_sort_pause);

        btnPauseDanPlay = (Button) findViewById(R.id.btn_pauseDanPlay);
        btnBackToSubMenu = (Button) findViewById(R.id.btn_backToSubMenu);
        imageView = (ImageView) findViewById(R.id.gifImageView_konten);
        deskripsi = (TextView) findViewById(R.id.Text_view_deskripsi);

        btnPauseDanPlay.setOnClickListener(this);
        btnBackToSubMenu.setOnClickListener(this);

        retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        jsonPlaceholderAPI = retrofit.create(JsonPlaceholderAPI.class);
        fetchComments();
    }

    private void fetchComments() {
        Call<List<Comment>> call = jsonPlaceholderAPI.getComments();
        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if (!response.isSuccessful()) {
                    // Handle error
                    return;
                }

                List<Comment> comments = response.body();
                if (comments != null && !comments.isEmpty()) {
                    Comment firstComment = comments.get(0);
                    String body = firstComment.getBody();
                    deskripsi.setText(body);
                }
            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                // Handle failure
            }
        });
    }

    public void onClick(View view) {
        Intent i;
        if (view.getId() == R.id.btn_backToSubMenu) {
            i = new Intent(this, MenuUtamaSub.class);
            startActivity(i);
        } else if (view.getId() == R.id.btn_pauseDanPlay) {
            i = new Intent(this, SortBubbleSort.class);
            startActivity(i);
        }
    }
}
