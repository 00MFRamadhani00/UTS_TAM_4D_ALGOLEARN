package com.fadhilah.algolearn;

import java.util.ArrayList;

public class ItemMenuSub {
    public static String[][] data = new String[][]{
            {"Bubble Sort", "0"},
            {"Selection Sort", "1"},
            {"Insertion Sort", "2"},
            {"Heap Sort", "3"}
    };

    public static int[] data1 = new int[]{
            1,
            2,
            3,
            4
    };

    public static ArrayList<ItemSub> getListData() {
        ArrayList<ItemSub> list = new ArrayList<>();
        for (int i = 0; i < data.length; i++) {
            ItemSub item = new ItemSub();
            item.setTitle(data[i][0]);
            item.setIndex(data[i][1]);
            list.add(item);
        }
        return list;
    }


}
