package com.fadhilah.algolearn;

import java.util.ArrayList;

public class ItemMenu {
    public static String[][] data = new String[][]{
            {"SORT", "4 Algorithm", "drawable://sort"},
            {"SEARCH", "3 Algorithm", "drawable://search"},
            {"TREE", "2 Algorithm", "drawable://tree"},
            {"GRAPH", "5 Algorithm", "drawable://graph"}
    };

    public static ArrayList<Item> getListData() {
        ArrayList<Item> list = new ArrayList<>();
        for (int i = 0; i < data.length; i++) {
            Item item = new Item();
            item.setTitle(data[i][0]);
            item.setSubtitle(data[i][1]);
            item.setGambar(data[i][2]);
            list.add(item);
        }
        return list;
    }
}
