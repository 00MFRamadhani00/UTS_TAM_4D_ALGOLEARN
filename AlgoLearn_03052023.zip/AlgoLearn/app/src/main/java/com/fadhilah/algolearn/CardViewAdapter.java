package com.fadhilah.algolearn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;

public class CardViewAdapter extends RecyclerView.Adapter<CardViewAdapter.CardViewViewHolder> {
    private ArrayList<Item> itemList;
    private Context context;
    public CardViewAdapter(Context context) {
        this.context = context;
    }
    public ArrayList<Item> getContactList() {
        return itemList;
    }
    public void setContactList(ArrayList<Item> itemList) {
        this.itemList = itemList;
    }

    @Override
    public CardViewViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_item_menu, parent, false);
        CardViewViewHolder viewHolder = new CardViewViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CardViewViewHolder holder, int position) {
        Item c = getContactList().get(position);
//        Glide.with(context).load(c.getGambar()).override(350,550).into(holder.item_icon);
        holder.tv_item_title.setText(c.getTitle());
        holder.tv_item_subtitle.setText(c.getSubtitle());
        String gambarUrl = Item.getGambar();
        if (gambarUrl != null && gambarUrl.startsWith("drawable://" )) {
            String resourceName = gambarUrl.substring("drawable://".length());
            int resourceId = context.getResources().getIdentifier(resourceName, "drawable", context.getPackageName());
            holder.item_icon.setImageResource(resourceId);
        } else {
            // Handle other types of image URLs if necessary
        }

        holder.item_btn.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                Toast.makeText(context, getContactList().get(position).getTitle()+" Added to Cart", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    @Override
    public int getItemCount() {
        return getContactList().size();
    }
    public class CardViewViewHolder extends RecyclerView.ViewHolder {
        ImageView item_icon;
        TextView tv_item_title,tv_item_subtitle;
        LinearLayout item_btn;

        public CardViewViewHolder(View itemView) {
            super(itemView);
            item_icon = (ImageView)itemView.findViewById(R.id.item_icon);
            tv_item_title = (TextView)itemView.findViewById(R.id.tv_item_title);
            tv_item_subtitle = (TextView)itemView.findViewById(R.id.tv_item_subtitle);
            item_btn = (LinearLayout)itemView.findViewById(R.id.item_btn);
        }
    }
}

