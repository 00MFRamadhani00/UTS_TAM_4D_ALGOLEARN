package com.fadhilah.algolearn;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CardViewAdapterSubmenu extends RecyclerView.Adapter<CardViewAdapterSubmenu.CardViewHolder> {
    private ArrayList<ItemSubmenu> itemList;
    private Context context;
    public CardViewAdapterSubmenu(Context context) {
        this.context = context;
    }
    public ArrayList<ItemSubmenu> getContactList() {
        return itemList;
    }
    public void setContactList(ArrayList<ItemSubmenu> itemList) {
        this.itemList = itemList;
    }

    @Override
    public CardViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_item_submenu, parent, false);
        CardViewHolder viewHolder = new CardViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(CardViewHolder holder, int position) {
        ItemSubmenu c = getContactList().get(position);
        holder.tv_item_title.setText(c.getTitle());
        holder.item_btn.setOnClickListener(new CustomOnItemClickListener(position, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                Toast.makeText(context, getContactList().get(position).getTitle()+" Clicked", Toast.LENGTH_SHORT).show();
            }
        }));
    }

    @Override
    public int getItemCount() {
        return getContactList().size();
    }
    public class CardViewHolder extends RecyclerView.ViewHolder {
        ImageView item_icon;
        TextView tv_item_title,tv_item_subtitle;
        LinearLayout item_btn;

        public CardViewHolder(View itemView) {
            super(itemView);
            item_icon = (ImageView)itemView.findViewById(R.id.item_icon);
            tv_item_title = (TextView)itemView.findViewById(R.id.tv_item_title);
            tv_item_subtitle = (TextView)itemView.findViewById(R.id.tv_item_subtitle);
            item_btn = (LinearLayout)itemView.findViewById(R.id.item_btn);
        }
    }
}

