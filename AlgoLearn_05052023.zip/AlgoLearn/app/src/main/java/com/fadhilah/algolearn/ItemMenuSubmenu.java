package com.fadhilah.algolearn;

import java.util.ArrayList;

public class ItemMenuSubmenu {
    public static String[] data = {"Bubble Sort", "Quick Sort", "Selection Sort", "Insertion Sort"};

    public static ArrayList<ItemSubmenu> getListData() {
        ArrayList<ItemSubmenu> list = new ArrayList<>();
        for (int i = 0; i < data.length; i++) {
            ItemSubmenu item = new ItemSubmenu();
            item.setTitle(data[i]);
            list.add(item);
        }
        return list;
    }
}
