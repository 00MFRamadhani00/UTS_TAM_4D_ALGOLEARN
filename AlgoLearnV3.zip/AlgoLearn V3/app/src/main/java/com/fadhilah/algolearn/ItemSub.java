package com.fadhilah.algolearn;

public class ItemSub {
    private String title;

    private String index;

    public String getTitle() {
        return title;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) { this.index = index; }

    public void setTitle(String title) {
        this.title = title;
    }
}
